$(document).ready(function () {
    $('#mobile_btn').on('click', function () {
        $('#mobile_menu').toggleClass('active');
        $('#mobile_btn').find('i').toggleClass('fa-x');
    });

    const section = $('section');
    const navItems = $('.nav_item');

    $(window).on('scroll', function () {
        const scrollPosition = $(window).scrollTop() + 100; // margem pra considerar sticky header
    
        $('.nav_item').each(function () {
            const link = $(this).find('a');
            const targetId = link.attr('href');
    
            if ($(targetId).length) {
                const sectionTop = $(targetId).offset().top;
                const sectionBottom = sectionTop + $(targetId).outerHeight();
    
                if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                    $('.nav_item').removeClass('active');
                    $(this).addClass('active');
                }
            }
        });
    });
});
